# 🐙 Octopus World Website

Simple static website themed about octopus.

## Features
- Responsive layout
- Modern ocean-style design
- Interactive contact form
- Clean folder structure

## How to Run
Open `index.html` in your browser.

## Perfect For
- Beginner frontend project
- GitHub portfolio
- HTML, CSS, JS practice
